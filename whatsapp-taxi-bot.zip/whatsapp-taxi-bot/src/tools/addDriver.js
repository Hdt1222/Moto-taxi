// Usage: npm run add-driver -- 6281234567890 "Budi Santoso" "B 1234 XYZ"
const db = require('../db');

const [, , number, name, plate] = process.argv;

if (!number || !name) {
  console.log('Usage: npm run add-driver -- <whatsapp_number> "<name>" "<plate>"');
  console.log('Example: npm run add-driver -- 6281234567890 "Budi Santoso" "B 1234 XYZ"');
  process.exit(1);
}

try {
  db.prepare(
    `INSERT INTO drivers (whatsapp_number, name, vehicle_plate, status) VALUES (?, ?, ?, 'offline')`
  ).run(number, name, plate || null);
  console.log(`✅ Driver added: ${name} (${number}). They should message the bot and reply "online" to start receiving rides.`);
} catch (err) {
  if (err.message.includes('UNIQUE')) {
    console.log('A driver with that WhatsApp number already exists.');
  } else {
    console.error(err);
  }
}
