const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const { handleCustomerMessage } = require('./customerFlow');
const { handleDriverMessage, getDriver } = require('./driverFlow');

function createBot() {
  const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: { args: ['--no-sandbox', '--disable-setuid-sandbox'] },
  });

  client.on('qr', (qr) => {
    console.log('Scan this QR code with WhatsApp (Linked Devices):');
    qrcode.generate(qr, { small: true });
  });

  client.on('ready', () => {
    console.log('✅ WhatsApp bot is ready.');
  });

  client.on('auth_failure', (msg) => {
    console.error('Authentication failed:', msg);
  });

  client.on('disconnected', (reason) => {
    console.warn('Client disconnected:', reason);
  });

  client.on('message', async (msg) => {
    try {
      // Ignore group messages and status updates; this bot is 1:1 only.
      if (msg.from.endsWith('@g.us') || msg.isStatus) return;

      const from = msg.from.replace('@c.us', '');
      const driver = getDriver(from);

      if (driver) {
        await handleDriverMessage(msg, client, from, driver);
      } else {
        await handleCustomerMessage(msg, client, from);
      }
    } catch (err) {
      console.error('Error handling message:', err);
      try {
        await msg.reply('⚠️ Something went wrong. Please try again, or reply *menu*.');
      } catch (_) {
        /* ignore secondary failure */
      }
    }
  });

  return client;
}

module.exports = { createBot };
