const db = require('./db');
const { clearOfferTimeout } = require('./driverMatcher');
const { formatMoney } = require('./pricing');

function getDriver(number) {
  return db.prepare('SELECT * FROM drivers WHERE whatsapp_number = ?').get(number);
}

function currentOfferedRide(driverId) {
  // Most recent ride still in "offered" state that lists this driver last.
  const rides = db
    .prepare(`SELECT * FROM rides WHERE status = 'offered' ORDER BY id DESC`)
    .all();
  return rides.find((r) => {
    const ids = JSON.parse(r.offered_driver_ids || '[]');
    return ids[ids.length - 1] === driverId;
  });
}

function activeAssignedRide(driverId) {
  return db
    .prepare(
      `SELECT * FROM rides WHERE driver_id = ?
       AND status IN ('assigned','arrived','in_progress')
       ORDER BY id DESC LIMIT 1`
    )
    .get(driverId);
}

async function handleDriverMessage(msg, client, from, driver) {
  const body = (msg.body || '').trim();
  const lower = body.toLowerCase();

  if (lower === 'online') {
    db.prepare(`UPDATE drivers SET status = 'online' WHERE id = ?`).run(driver.id);
    await msg.reply('✅ You are now *online* and can receive ride requests.');
    return;
  }

  if (lower === 'offline') {
    db.prepare(`UPDATE drivers SET status = 'offline' WHERE id = ?`).run(driver.id);
    await msg.reply('🔴 You are now *offline*.');
    return;
  }

  if (msg.location) {
    db.prepare(`UPDATE drivers SET lat = ?, lng = ? WHERE id = ?`).run(
      msg.location.latitude,
      msg.location.longitude,
      driver.id
    );
    await msg.reply('📍 Location updated.');
    return;
  }

  if (lower === '1' || lower === '2') {
    const ride = currentOfferedRide(driver.id);
    if (!ride) {
      await msg.reply('No ride offer is currently waiting on you.');
      return;
    }
    clearOfferTimeout(ride.id);

    if (lower === '1') {
      db.prepare(
        `UPDATE rides SET status = 'assigned', driver_id = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(driver.id, ride.id);
      db.prepare(`UPDATE drivers SET status = 'busy' WHERE id = ?`).run(driver.id);

      await msg.reply(
        `✅ Ride #${ride.id} accepted. Head to pickup: ${ride.pickup_label}\n\n` +
          `Reply *arrived* when you reach the pickup, *start* when the ride begins, ` +
          `and *done* when it's complete.`
      );
      await client.sendMessage(
        `${ride.customer_number}@c.us`,
        `🛵 Driver *${driver.name}* (${driver.vehicle_plate || 'plate n/a'}) accepted your ride #${ride.id} and is on the way!`
      );
    } else {
      db.prepare(
        `UPDATE rides SET status = 'searching', updated_at = datetime('now') WHERE id = ?`
      ).run(ride.id);
      await msg.reply('Declined. Thanks for the quick response.');

      const { offerToNextDriver } = require('./driverMatcher');
      await offerToNextDriver(ride.id, {
        onOffer: async (nextDriver, r) => {
          await client.sendMessage(
            `${nextDriver.whatsapp_number}@c.us`,
            `🛵 *New ride request* #${r.id}\n\n` +
              `📍 Pickup: ${r.pickup_label}\n🎯 Drop-off: ${r.dest_label}\n` +
              (r.fare ? `💰 Fare: ${formatMoney(r.fare)}\n` : '') +
              `\nReply *1* to accept or *2* to decline.`
          );
        },
        onNoDrivers: async (r) => {
          await client.sendMessage(
            `${r.customer_number}@c.us`,
            '😔 No drivers are available right now. Please try again shortly by replying *book*.'
          );
        },
      });
    }
    return;
  }

  if (['arrived', 'start', 'done'].includes(lower)) {
    const ride = activeAssignedRide(driver.id);
    if (!ride) {
      await msg.reply('You have no active assigned ride.');
      return;
    }

    const nextStatus = { arrived: 'arrived', start: 'in_progress', done: 'completed' }[lower];
    db.prepare(
      `UPDATE rides SET status = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(nextStatus, ride.id);

    const customerMsgMap = {
      arrived: `🛵 Your driver has *arrived* at the pickup point.`,
      in_progress: `🚦 Your ride #${ride.id} has *started*.`,
      completed: `🏁 Ride #${ride.id} *completed*. Fare: ${formatMoney(ride.fare || 0)}\n\nThanks for riding with MotoGo!`,
    };
    await client.sendMessage(`${ride.customer_number}@c.us`, customerMsgMap[nextStatus]);

    if (nextStatus === 'completed') {
      db.prepare(`UPDATE drivers SET status = 'online' WHERE id = ?`).run(driver.id);
      await msg.reply(`✅ Ride #${ride.id} marked complete. You're back online.`);
    } else {
      await msg.reply(`Status updated to *${nextStatus}*.`);
    }
    return;
  }

  await msg.reply(
    `Driver commands:\n` +
      `• *online* / *offline* — toggle availability\n` +
      `• Share 📍 location — update your position\n` +
      `• *1* / *2* — accept / decline an offered ride\n` +
      `• *arrived* / *start* / *done* — update an active ride`
  );
}

module.exports = { handleDriverMessage, getDriver };
