const Database = require('better-sqlite3');
require('dotenv').config();

const db = new Database(process.env.DB_PATH || './taxi.db');
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS drivers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  whatsapp_number TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  vehicle_plate TEXT,
  status TEXT NOT NULL DEFAULT 'offline',   -- offline | online | busy
  lat REAL,
  lng REAL,
  rating_sum INTEGER NOT NULL DEFAULT 0,
  rating_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_number TEXT NOT NULL,
  pickup_label TEXT,
  pickup_lat REAL,
  pickup_lng REAL,
  dest_label TEXT,
  dest_lat REAL,
  dest_lng REAL,
  distance_km REAL,
  fare INTEGER,
  driver_id INTEGER,
  status TEXT NOT NULL DEFAULT 'pending',
  -- pending | searching | offered | assigned | arrived | in_progress | completed | cancelled | no_driver
  offered_driver_ids TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);
`);

module.exports = db;
