require('./db'); // ensures tables exist on startup
const { createBot } = require('./bot');

const client = createBot();
client.initialize();
