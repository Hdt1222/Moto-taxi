require('dotenv').config();
require('./db'); // ensures tables exist on startup
const { createBot } = require('./bot');
const { startKeepAliveServer } = require('./keepalive');

startKeepAliveServer();

createBot().catch((err) => {
  console.error('Failed to start bot:', err);
  process.exit(1);
});
